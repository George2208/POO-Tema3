#ifndef BASE_H
#define BASE_H


class Base
{
    public:
        virtual int calcul()=0;
};

#endif
