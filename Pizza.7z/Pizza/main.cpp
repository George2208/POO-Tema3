#include <Pizza_Vegetariana.h>
#include <Meniu.h>

using namespace std;

int main()
{
    Meniu<Pizza, Pizza_Vegetariana> m("init");
    return 0;
}
